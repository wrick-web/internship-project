// lib/db.ts
import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI!;
const client = new MongoClient(uri);

export async function connectDB() {
  if (!client.isConnected?.()) await client.connect();
  return client.db("financeApp");
}
// pages/api/transactions/index.ts
import { connectDB } from "@/lib/db";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = await connectDB();
  const collection = db.collection("transactions");

  if (req.method === "GET") {
    const transactions = await collection.find().toArray();
    return res.status(200).json(transactions);
  }

  if (req.method === "POST") {
    const body = req.body;
    await collection.insertOne(body);
    return res.status(201).json({ message: "Transaction added" });
  }

  if (req.method === "DELETE") {
    const { id } = req.query;
    await collection.deleteOne({ _id: new ObjectId(id as string) });
    return res.status(200).json({ message: "Transaction deleted" });
  }

  res.status(405).json({ message: "Method not allowed" });
}
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/
"use client";
import { useState } from "react";

export default function TransactionForm({ onAdd }: { onAdd: () => void }) {
  const [form, setForm] = useState({ amount: "", date: "", description: "" });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    if (!form.amount || !form.date || !form.description) return alert("All fields required");
    await fetch("/api/transactions", {
      method: "POST",
      body: JSON.stringify(form),
      headers: { "Content-Type": "application/json" },
    });
    setForm({ amount: "", date: "", description: "" });
    onAdd(); // Refresh
  };

  return (
    <div className="space-y-2">
      <input name="amount" placeholder="Amount" value={form.amount} onChange={handleChange} />
      <input name="date" type="date" value={form.date} onChange={handleChange} />
      <input name="description" placeholder="Description" value={form.description} onChange={handleChange} />
      <button onClick={handleSubmit}>Add Transaction</button>
    </div>
  );
}
"use client";
import { useEffect, useState } from "react";

export default function TransactionList() {
  const [transactions, setTransactions] = useState<any[]>([]);

  const load = async () => {
    const res = await fetch("/api/transactions");
    const data = await res.json();
    setTransactions(data);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div>
      <h2>Transactions</h2>
      <ul>
        {transactions.map((t) => (
          <li key={t._id}>{t.date} - ₹{t.amount} - {t.description}</li>
        ))}
      </ul>
    </div>
  );
}
"use client";
import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

export default function MonthlyBarChart() {
  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    fetch("/api/transactions")
      .then((res) => res.json())
      .then((transactions) => {
        const grouped = transactions.reduce((acc: any, t: any) => {
          const month = new Date(t.date).toLocaleString("default", { month: "short", year: "numeric" });
          acc[month] = (acc[month] || 0) + Number(t.amount);
          return acc;
        }, {});
        const formatted = Object.entries(grouped).map(([month, total]) => ({ month, total }));
        setData(formatted);
      });
  }, []);

  return (
    <div className="h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="total" fill="#8884d8" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
import TransactionForm from "@/components/TransactionForm";
import TransactionList from "@/components/TransactionList";
import MonthlyBarChart from "@/components/MonthlyBarChart";

export default function Home() {
  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">Personal Finance Visualizer</h1>
      <TransactionForm onAdd={() => window.location.reload()} />
      <TransactionList />
      <MonthlyBarChart />
    </main>
  );
}
npm install recharts
MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/?retryWrites=true&w=majority
