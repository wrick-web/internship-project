// utils/mongodb.ts
import { MongoClient } from 'mongodb';

const client = new MongoClient(process.env.MONGODB_URI as string);

export const connectToDatabase = async () => {
  if (!client.isConnected()) await client.connect(); // Connect if not already connected
  const db = client.db('financeDB'); // Name of your MongoDB database
  return { db };
};
