// pages/dashboard.tsx
import React, { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend } from 'recharts';
import { getTransactions } from '../utils/api'; // API to fetch transactions

const Dashboard = () => {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [budgets, setBudgets] = useState<any[]>([]);
  const [totalIncome, setTotalIncome] = useState(0);
  const [totalExpenses, setTotalExpenses] = useState(0);
  const [balance, setBalance] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      const transactionsData = await getTransactions();
      setTransactions(transactionsData);
      
      const budgetsData = await fetch('/api/budgets').then(res => res.json());
      setBudgets(budgetsData);
    };
    
    fetchData();
  }, []);

  // Calculate total income, expenses, and balance
  useEffect(() => {
    const income = transactions.filter((t) => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
    const expenses = transactions.filter((t) => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);

    setTotalIncome(income);
    setTotalExpenses(expenses);
    setBalance(income - expenses);
  }, [transactions]);

  // Prepare category-wise breakdown
  const categories = transactions
    .filter((t) => t.type === 'expense')
    .reduce((acc, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {} as Record<string, number>);

  const categoryData = Object.keys(categories).map((category) => ({
    name: category,
    value: categories[category],
  }));

  // Compare actual expenses vs budgeted amounts
  const budgetComparison = budgets.map((budget) => {
    const actualExpense = categories[budget.category] || 0;
    const remainingBudget = budget.budgetLimit - actualExpense;
    return {
      category: budget.category,
      budgetLimit: budget.budgetLimit,
      actualExpense,
      remainingBudget,
    };
  });

  return (
    <div>
      <h1>Dashboard</h1>
      <div>
        <h2>Total Income: ${totalIncome}</h2>
        <h2>Total Expenses: ${totalExpenses}</h2>
        <h2>Balance: ${balance}</h2>
      </div>

      {/* Pie Chart for category breakdown */}
      <div style={{ width: '100%', height: 400 }}>
        <PieChart width={400} height={400}>
          <Pie
            data={categoryData}
            dataKey="value"
            nameKey="name"
            outerRadius={150}
            fill="#8884d8"
            label
          >
            {categoryData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getRandomColor()} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </div>

      {/* Budget Comparison Table */}
      <h2>Budget vs Actual</h2>
      <table>
        <thead>
          <tr>
            <th>Category</th>
            <th>Budget Limit</th>
            <th>Actual Expense</th>
            <th>Remaining Budget</th>
          </tr>
        </thead>
        <tbody>
          {budgetComparison.map((item) => (
            <tr key={item.category}>
              <td>{item.category}</td>
              <td>${item.budgetLimit}</td>
              <td>${item.actualExpense}</td>
              <td>${item.remainingBudget}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Dashboard;

// Helper function to generate random colors for Pie chart
const getRandomColor = () => {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};
// Add this inside the return statement in Dashboard.tsx before rendering the budget comparison table
const [newCategory, setNewCategory] = useState('');
const [newBudgetLimit, setNewBudgetLimit] = useState('');
const [newMonth, setNewMonth] = useState('April');
const [newYear, setNewYear] = useState(2025);

const handleCreateBudget = async (e: React.FormEvent) => {
  e.preventDefault();
  const response = await fetch('/api/budgets', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      category: newCategory,
      budgetLimit: parseFloat(newBudgetLimit),
      month: newMonth,
      year: newYear,
    }),
  });
  if (response.ok) {
    alert('Budget created successfully');
    setNewCategory('');
    setNewBudgetLimit('');
  } else {
    alert('Failed to create budget');
  }
};

return (
  <div>
    <h2>Create New Budget</h2>
    <form onSubmit={handleCreateBudget}>
      <label>
        Category:
        <input
          type="text"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          required
        />
      </label>
      <label>
        Budget Limit:
        <input
          type="number"
          value={newBudgetLimit}
          onChange={(e) => setNewBudgetLimit(e.target.value)}
          required
        />
      </label>
      <label>
        Month:
        <input
          type="text"
          value={newMonth}
          onChange={(e) => setNewMonth(e.target.value)}
        />
      </label>
      <label>
        Year:
        <input
          type="number"
          value={newYear}
          onChange={(e) => setNewYear(e.target.value)}
        />
      </label>
      <button type="submit">Create Budget</button>
    </form>
  </div>
);
