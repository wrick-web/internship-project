import { connectDB } from "@/lib/db";
import { NextApiRequest, NextApiResponse } from "next";
import { ObjectId } from "mongodb";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const db = await connectDB();
  const collection = db.collection("transactions");

  if (req.method === "GET") {
    const transactions = await collection.find().toArray();
    return res.status(200).json(transactions);
  }

  if (req.method === "POST") {
    const body = req.body;
    await collection.insertOne(body);
    return res.status(201).json({ message: "Transaction added" });
  }

  if (req.method === "DELETE") {
    const { id } = req.query;
    await collection.deleteOne({ _id: new ObjectId(id as string) });
    return res.status(200).json({ message: "Transaction deleted" });
  }

  res.status(405).json({ message: "Method not allowed" });
}
