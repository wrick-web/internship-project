// pages/api/budgets.ts
import { NextApiRequest, NextApiResponse } from 'next';
import { connectToDatabase } from '../../utils/mongodb';

export default async (req: NextApiRequest, res: NextApiResponse) => {
  const { db } = await connectToDatabase();

  if (req.method === 'GET') {
    // Fetch budgets for the current month
    const budgets = await db.collection('budgets').find().toArray();
    res.status(200).json(budgets);
  } else if (req.method === 'POST') {
    // Add a new budget
    const { category, budgetLimit, month, year } = req.body;
    await db.collection('budgets').insertOne({ category, budgetLimit, month, year });
    res.status(201).json({ message: 'Budget added successfully' });
  }
};
